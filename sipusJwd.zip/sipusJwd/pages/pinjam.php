<div id="content">
	<table id="tabel-tampil">

<html>
<body>
<h2> Pinjam </h2>
 <form method = 'post' action= "cetak/cetak-transaksi-peminjaman-pengembalian.php">
  <table>
   <tr>
    <td> Tanggal Awal Peminjaman </td>
    <td>:</td>
    <td><input type='date' name='tglawal'></td>
   </tr>
   <tr>
    <td> Tanggal Akhir Pengembalian </td>
    <td>:</td>
    <td><input type='date' name='tglakhir'></td>
   </tr>
   <tr>
    <td></td>
    <td></td>
    <td><button type="submit"> Cetak </button></button> </button>
   </tr>
  </table>  
 </form>
</body>
</html>


